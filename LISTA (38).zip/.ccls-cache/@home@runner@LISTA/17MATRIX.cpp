#include <iostream>
using namespace std;

const int SIZE = 3;

// Função para multiplicar duas matrizes A e B e armazenar o resultado em C
void multiplicarMatrizes(int A[][SIZE], int B[][SIZE], int C[][SIZE]) {
    for (int i = 0; i < SIZE; ++i) {
        for (int j = 0; j < SIZE; ++j) {
            C[i][j] = 0;
            for (int k = 0; k < SIZE; ++k) {
                C[i][j] += A[i][k] * B[k][j];
            }
        }
    }
}

// Função para imprimir uma matriz
void imprimirMatriz(int matriz[][SIZE]) {
    for (int i = 0; i < SIZE; ++i) {
        for (int j = 0; j < SIZE; ++j) {
            cout << matriz[i][j] << " ";
        }
        cout << endl;
    }
}

int main() {
    int A[SIZE][SIZE];
    int B[SIZE][SIZE];
    int C[SIZE][SIZE];

    // Leitura da matriz A
    cout << "Digite os elementos da matriz A:" << endl;
    for (int i = 0; i < SIZE; ++i) {
        for (int j = 0; j < SIZE; ++j) {
            cout << "A[" << i << "][" << j << "]: ";
            cin >> A[i][j];
        }
    }

    // Leitura da matriz B
    cout << "\nDigite os elementos da matriz B:" << endl;
    for (int i = 0; i < SIZE; ++i) {
        for (int j = 0; j < SIZE; ++j) {
            cout << "B[" << i << "][" << j << "]: ";
            cin >> B[i][j];
        }
    }

    // Chamando a função para multiplicar as matrizes A e B
    multiplicarMatrizes(A, B, C);

    // Impressão das matrizes e do resultado
    cout << "\nMatriz A:" << endl;
    imprimirMatriz(A);

    cout << "\nMatriz B:" << endl;
    imprimirMatriz(B);

    cout << "\nMatriz C = A * B:" << endl;
    imprimirMatriz(C);

    return 0;
}
