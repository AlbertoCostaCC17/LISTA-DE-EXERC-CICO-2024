#include <iostream>
using namespace std;

const int SIZE = 3;

// Função para calcular A^2 e armazenar em B
void calcularMatrizQuadrada(int A[][SIZE], int B[][SIZE]) {
    int C[SIZE][SIZE]; // Matriz auxiliar para armazenar o resultado parcial

    for (int i = 0; i < SIZE; ++i) {
        for (int j = 0; j < SIZE; ++j) {
            C[i][j] = 0;
            for (int k = 0; k < SIZE; ++k) {
                C[i][j] += A[i][k] * A[k][j];
            }
        }
    }

    // Copiando os valores de C para B
    for (int i = 0; i < SIZE; ++i) {
        for (int j = 0; j < SIZE; ++j) {
            B[i][j] = C[i][j];
        }
    }
}

// Função para imprimir uma matriz
void imprimirMatriz(int matriz[][SIZE]) {
    for (int i = 0; i < SIZE; ++i) {
        for (int j = 0; j < SIZE; ++j) {
            cout << matriz[i][j] << " ";
        }
        cout << endl;
    }
}

int main() {
    int A[SIZE][SIZE];
    int B[SIZE][SIZE];

    // Leitura da matriz A
    cout << "Digite os elementos da matriz A:" << endl;
    for (int i = 0; i < SIZE; ++i) {
        for (int j = 0; j < SIZE; ++j) {
            cout << "A[" << i << "][" << j << "]: ";
            cin >> A[i][j];
        }
    }

    // Chamando a função para calcular A^2
    calcularMatrizQuadrada(A, B);

    // Impressão das matrizes
    cout << "\nMatriz A:" << endl;
    imprimirMatriz(A);

    cout << "\nMatriz B = A^2:" << endl;
    imprimirMatriz(B);

    return 0;
}
