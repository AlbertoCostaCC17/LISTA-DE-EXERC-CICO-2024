#include <iostream>
#include <ctime>
using namespace std;

const int LINHAS = 5;
const int COLUNAS = 5;

int main() {
    int cartela[LINHAS][COLUNAS] = {0};

    srand(time(NULL));

    // Preenchendo a cartela sem números repetidos
    for (int i = 0; i < LINHAS; ++i) {
        for (int j = 0; j < COLUNAS; ++j) {
            int numero;
            bool repetido;
            do {
                numero = rand() % 100;
                repetido = false;
                // Verificando se o número já está na cartela
                for (int k = 0; k < i * COLUNAS + j; ++k) {
                    if (cartela[k / COLUNAS][k % COLUNAS] == numero) {
                        repetido = true;
                        break;
                    }
                }
            } while (repetido);
            cartela[i][j] = numero;
        }
    }

    // Exibindo a cartela gerada
    cout << "Cartela de Bingo gerada:" << endl;
    for (int i = 0; i < LINHAS; ++i) {
        for (int j = 0; j < COLUNAS; ++j) {
            cout << cartela[i][j] << "\t";
        }
        cout << endl;
    }

    return 0;
}
