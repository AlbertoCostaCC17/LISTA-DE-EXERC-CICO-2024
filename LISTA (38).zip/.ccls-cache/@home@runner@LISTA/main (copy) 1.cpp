#include <stdio.h>

int main() {
    // Declarando o vetor A com 6 elementos
    int A[6];

    // (a) Atribuindo os valores ao vetor A
    A[0] = 1;
    A[1] = 0;
    A[2] = 5;
    A[3] = -2;
    A[4] = -5;
    A[5] = 7;

    // (b) Calculando e mostrando a soma de A[0], A[1] e A[5]
    int soma = A[0] + A[1] + A[5];
    printf("Soma de A[0], A[1] e A[5]: %d\n", soma);

    // (c) Modificando A[4] para 100
    A[4] = 100;

    // (d) Mostrando cada valor do vetor A
    printf("Valores do vetor A:\n");
    for (int i = 0; i < 6; i++) {
        printf("A[%d] = %d\n", i, A[i]);
    }

    return 0;
}
