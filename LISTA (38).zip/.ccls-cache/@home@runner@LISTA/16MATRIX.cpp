#include <iostream>
using namespace std;

const int ALUNOS = 3;
const int QUESTOES = 10;

int main() {
    char gabarito[QUESTOES];
    char respostas_alunos[ALUNOS][QUESTOES];
    int matriculas[ALUNOS];
    float notas[ALUNOS];
    float media_aprovacao = 7.0;
    int aprovados = 0;

    // Leitura do gabarito
    cout << "Digite o gabarito da prova (10 respostas A, B, C, D ou E):" << endl;
    for (int i = 0; i < QUESTOES; ++i) {
        cout << "Questao " << i + 1 << ": ";
        cin >> gabarito[i];
    }

    // Leitura das respostas dos alunos e cálculo das notas
    for (int i = 0; i < ALUNOS; ++i) {
        // Leitura da matrícula
        cout << "\nDigite a matricula do aluno " << i + 1 << ": ";
        cin >> matriculas[i];

        // Leitura das respostas do aluno
        cout << "Digite as respostas do aluno " << i + 1 << " (10 respostas A, B, C, D ou E):" << endl;
        for (int j = 0; j < QUESTOES; ++j) {
            cout << "Resposta " << j + 1 << ": ";
            cin >> respostas_alunos[i][j];
        }

        // Cálculo da nota do aluno
        notas[i] = 0;
        for (int j = 0; j < QUESTOES; ++j) {
            if (respostas_alunos[i][j] == gabarito[j]) {
                notas[i]++;
            }
        }

        // Verificação se o aluno foi aprovado
        if (notas[i] >= media_aprovacao) {
            aprovados++;
        }
    }

    // Impressão dos resultados
    cout << "\nResultados da prova:" << endl;
    for (int i = 0; i < ALUNOS; ++i) {
        cout << "Aluno " << i + 1 << endl;
        cout << "Matricula: " << matriculas[i] << endl;
        cout << "Respostas: ";
        for (int j = 0; j < QUESTOES; ++j) {
            cout << respostas_alunos[i][j] << " ";
        }
        cout << "\nNota: " << notas[i] << endl;
        cout << endl;
    }

    // Cálculo do percentual de aprovação
    float percentual_aprovacao = (static_cast<float>(aprovados) / ALUNOS) * 100;
    cout << "Percentual de aprovacao: " << percentual_aprovacao << "%" << endl;

    return 0;
}
