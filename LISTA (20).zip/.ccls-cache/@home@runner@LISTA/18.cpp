#include <iostream>
using namespace std;

int main() {
    const int TAMANHO = 10;
    int vetor[TAMANHO];
    int x;

    // Leitura do vetor
    cout << "Digite 10 numeros inteiros para preencher o vetor:" << endl;
    for (int i = 0; i < TAMANHO; ++i) {
        cout << "Numero " << i+1 << ": ";
        cin >> vetor[i];
    }

    // Leitura do numero x
    cout << "\nDigite um numero inteiro x para contar seus multiplos no vetor: ";
    cin >> x;

    // Contagem e impressao dos multiplos de x
    cout << "\nMultiplos de " << x << " no vetor:" << endl;
    int contador = 0;
    for (int i = 0; i < TAMANHO; ++i) {
        if (vetor[i] % x == 0) {
            cout << vetor[i] << " ";
            contador++;
        }
    }

    if (contador == 0) {
        cout << "Nao foram encontrados multiplos de " << x << " no vetor." << endl;
    } else {
        cout << "\nTotal de multiplos de " << x << " encontrados: " << contador << endl;
    }

    return 0;
}
