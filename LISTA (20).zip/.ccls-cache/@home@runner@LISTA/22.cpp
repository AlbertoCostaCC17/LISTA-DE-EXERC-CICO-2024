#include <iostream>
using namespace std;

const int TAMANHO = 10;

int main() {
    int A[TAMANHO], B[TAMANHO], C[2 * TAMANHO];

    // Leitura dos vetores A e B
    cout << "Digite os 10 numeros inteiros do vetor A:" << endl;
    for (int i = 0; i < TAMANHO; ++i) {
        cout << "A[" << i << "]: ";
        cin >> A[i];
    }

    cout << "\nDigite os 10 numeros inteiros do vetor B:" << endl;
    for (int i = 0; i < TAMANHO; ++i) {
        cout << "B[" << i << "]: ";
        cin >> B[i];
    }

    // Preenchimento do vetor C com valores alternados de A e B
    int indiceC = 0;
    for (int i = 0; i < TAMANHO; ++i) {
        C[indiceC] = A[i];
        C[indiceC + 1] = B[i];
        indiceC += 2;
    }

    // Impressão do vetor C
    cout << "\nVetor C com valores alternados de A e B:" << endl;
    for (int i = 0; i < 2 * TAMANHO; ++i) {
        cout << C[i] << " ";
        if ((i + 1) % 2 == 0) {
            cout << endl; // Quebra de linha a cada dois elementos
        }
    }
    cout << endl;

    return 0;
}
