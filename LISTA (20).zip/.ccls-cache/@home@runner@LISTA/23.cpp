#include <iostream>
using namespace std;

const int TAMANHO = 5;

int main() {
    double vetorX[TAMANHO], vetorY[TAMANHO];
    double produtoEscalar = 0.0;

    // Leitura dos vetores X e Y
    cout << "Digite os 5 numeros reais do vetor X:" << endl;
    for (int i = 0; i < TAMANHO; ++i) {
        cout << "X[" << i << "]: ";
        cin >> vetorX[i];
    }

    cout << "\nDigite os 5 numeros reais do vetor Y:" << endl;
    for (int i = 0; i < TAMANHO; ++i) {
        cout << "Y[" << i << "]: ";
        cin >> vetorY[i];
    }

    // Cálculo do produto escalar
    for (int i = 0; i < TAMANHO; ++i) {
        produtoEscalar += vetorX[i] * vetorY[i];
    }

    // Impressão dos vetores X, Y e do produto escalar
    cout << "\nVetor X:" << endl;
    for (int i = 0; i < TAMANHO; ++i) {
        cout << vetorX[i] << " ";
    }
    cout << endl;

    cout << "\nVetor Y:" << endl;
    for (int i = 0; i < TAMANHO; ++i) {
        cout << vetorY[i] << " ";
    }
    cout << endl;

    cout << "\nProduto escalar entre X e Y: " << produtoEscalar << endl;

    return 0;
}
