#include <iostream>
using namespace std;

int main() {
    const int TAMANHO = 6;
    int valores[TAMANHO];

    // Leitura dos valores inteiros pares
    cout << "Digite 6 valores inteiros pares:" << endl;
    for (int i = 0; i < TAMANHO; ++i) {
        do {
            cout << "Valor " << i+1 << ": ";
            cin >> valores[i];
            if (valores[i] % 2 != 0) {
                cout << "O valor digitado nao eh par. Digite um valor par." << endl;
            }
        } while (valores[i] % 2 != 0);
    }

    // Impressão dos valores na ordem inversa
    cout << "\nValores na ordem inversa:" << endl;
    for (int i = TAMANHO - 1; i >= 0; --i) {
        cout << valores[i] << endl;
    }

    return 0;
}
