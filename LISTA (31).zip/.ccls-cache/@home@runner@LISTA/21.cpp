#include <iostream>
using namespace std;

const int TAMANHO = 10;

int main() {
    int A[TAMANHO], B[TAMANHO], C[TAMANHO];

    // Leitura dos vetores A e B
    cout << "Digite os 10 numeros inteiros do vetor A:" << endl;
    for (int i = 0; i < TAMANHO; ++i) {
        cout << "A[" << i << "]: ";
        cin >> A[i];
    }

    cout << "\nDigite os 10 numeros inteiros do vetor B:" << endl;
    for (int i = 0; i < TAMANHO; ++i) {
        cout << "B[" << i << "]: ";
        cin >> B[i];
    }

    // Cálculo do vetor C = A - B
    for (int i = 0; i < TAMANHO; ++i) {
        C[i] = A[i] - B[i];
    }

    // Impressão do vetor C
    cout << "\nVetor C = A - B:" << endl;
    for (int i = 0; i < TAMANHO; ++i) {
        cout << C[i] << " ";
    }
    cout << endl;

    return 0;
}
