#include <iostream>
using namespace std;

const int TAMANHO = 3;

int main() {
    int matriz[TAMANHO][TAMANHO];
    int soma_diagonal_principal = 0;

    // Leitura dos elementos da matriz
    cout << "Digite os elementos da matriz 3x3:" << endl;
    for (int i = 0; i < TAMANHO; ++i) {
        for (int j = 0; j < TAMANHO; ++j) {
            cout << "Elemento [" << i << "][" << j << "]: ";
            cin >> matriz[i][j];
        }
    }

    // Cálculo da soma dos elementos da diagonal principal
    for (int i = 0; i < TAMANHO; ++i) {
        soma_diagonal_principal += matriz[i][i];
    }

    // Impressão da soma dos elementos da diagonal principal
    cout << "Soma dos elementos da diagonal principal: " << soma_diagonal_principal << endl;

    return 0;
}
