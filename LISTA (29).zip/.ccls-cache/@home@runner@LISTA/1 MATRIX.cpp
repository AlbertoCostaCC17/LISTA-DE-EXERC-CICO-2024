#include <iostream>
using namespace std;

const int TAMANHO = 4;

int main() {
    int matriz[TAMANHO][TAMANHO];
    int contador = 0;

    // Leitura dos elementos da matriz
    cout << "Digite os elementos da matriz 4x4:" << endl;
    for (int i = 0; i < TAMANHO; ++i) {
        for (int j = 0; j < TAMANHO; ++j) {
            cout << "Elemento [" << i << "][" << j << "]: ";
            cin >> matriz[i][j];
            if (matriz[i][j] > 10) {
                contador++;
            }
        }
    }

    // Impressão da matriz
    cout << "\nMatriz digitada:" << endl;
    for (int i = 0; i < TAMANHO; ++i) {
        for (int j = 0; j < TAMANHO; ++j) {
            cout << matriz[i][j] << " ";
        }
        cout << endl;
    }

    // Impressão da quantidade de valores maiores que 10
    cout << "\nQuantidade de valores maiores que 10 na matriz: " << contador << endl;

    return 0;
}
