#include <iostream>
using namespace std;

const int TAMANHO = 4;

int main() {
    int matriz1[TAMANHO][TAMANHO];
    int matriz2[TAMANHO][TAMANHO];
    int matriz_maior[TAMANHO][TAMANHO];

    // Leitura da primeira matriz
    cout << "Digite os elementos da primeira matriz 4x4:" << endl;
    for (int i = 0; i < TAMANHO; ++i) {
        for (int j = 0; j < TAMANHO; ++j) {
            cout << "Elemento [" << i << "][" << j << "]: ";
            cin >> matriz1[i][j];
        }
    }

    // Leitura da segunda matriz
    cout << "Digite os elementos da segunda matriz 4x4:" << endl;
    for (int i = 0; i < TAMANHO; ++i) {
        for (int j = 0; j < TAMANHO; ++j) {
            cout << "Elemento [" << i << "][" << j << "]: ";
            cin >> matriz2[i][j];
        }
    }

    // Construção da matriz com os maiores valores
    for (int i = 0; i < TAMANHO; ++i) {
        for (int j = 0; j < TAMANHO; ++j) {
            matriz_maior[i][j] = max(matriz1[i][j], matriz2[i][j]);
        }
    }

    // Impressão da matriz com os maiores valores
    cout << "\nMatriz com os maiores valores de cada posicao das matrizes lidas:" << endl;
    for (int i = 0; i < TAMANHO; ++i) {
        for (int j = 0; j < TAMANHO; ++j) {
            cout << matriz_maior[i][j] << " ";
        }
        cout << endl;
    }

    return 0;
}
