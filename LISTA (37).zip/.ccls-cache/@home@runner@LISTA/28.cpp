#include <iostream>
#include <vector>
using namespace std;

int main() {
    const int TAMANHO = 10;
    vector<int> v(TAMANHO);
    vector<int> v1, v2;

    // Leitura dos elementos do vetor
    cout << "Digite os " << TAMANHO << " numeros inteiros do vetor:" << endl;
    for (int i = 0; i < TAMANHO; ++i) {
        cout << "Elemento " << i + 1 << ": ";
        cin >> v[i];

        if (v[i] % 2 == 0) {
            v2.push_back(v[i]); // Números pares vão para v2
        } else {
            v1.push_back(v[i]); // Números ímpares vão para v1
        }
    }

    // Impressão dos elementos UTILIZADOS de v1
    if (!v1.empty()) {
        cout << "\nElementos utilizados de v1 (numeros impares):" << endl;
        for (size_t i = 0; i < v1.size(); ++i) {
            cout << v1[i] << " ";
        }
        cout << endl;
    } else {
        cout << "\nNenhum elemento impar foi utilizado." << endl;
    }

    // Impressão dos elementos UTILIZADOS de v2
    if (!v2.empty()) {
        cout << "\nElementos utilizados de v2 (numeros pares):" << endl;
        for (size_t i = 0; i < v2.size(); ++i) {
            cout << v2[i] << " ";
        }
        cout << endl;
    } else {
        cout << "\nNenhum elemento par foi utilizado." << endl;
    }

    return 0;
}
