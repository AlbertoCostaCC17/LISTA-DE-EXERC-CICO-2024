#include <iostream>
using namespace std;

const int TAMANHO = 4;

int main() {
    int matriz[TAMANHO][TAMANHO];

    // Preenchimento da matriz
    for (int i = 0; i < TAMANHO; ++i) {
        for (int j = 0; j < TAMANHO; ++j) {
            matriz[i][j] = i * j;
        }
    }

    // Impressão da matriz
    cout << "Matriz com o produto do valor da linha e da coluna de cada elemento:" << endl;
    for (int i = 0; i < TAMANHO; ++i) {
        for (int j = 0; j < TAMANHO; ++j) {
            cout << matriz[i][j] << " ";
        }
        cout << endl;
    }

    return 0;
}
