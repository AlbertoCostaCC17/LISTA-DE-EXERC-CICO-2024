#include <iostream>
using namespace std;

int main() {
    const int TAMANHO = 8;
    int vetor[TAMANHO];
    int X, Y;

    // Leitura dos valores do vetor
    cout << "Digite 8 numeros inteiros:" << endl;
    for (int i = 0; i < TAMANHO; ++i) {
        cout << "Posicao " << i << ": ";
        cin >> vetor[i];
    }

    // Leitura das posicoes X e Y
    cout << "Digite dois numeros para as posicoes X e Y (0 a " << TAMANHO-1 << "): ";
    cin >> X >> Y;

    // Calculo da soma dos valores nas posicoes X e Y
    int soma = vetor[X] + vetor[Y];

    // Impressao da soma
    cout << "A soma dos valores nas posicoes " << X << " e " << Y << " eh: " << soma << endl;

    return 0;
}

