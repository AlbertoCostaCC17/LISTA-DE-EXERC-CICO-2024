#include <iostream>
using namespace std;

int main() {
    const int NUM_ALUNOS = 15;
    double notas[NUM_ALUNOS];
    double soma = 0.0;
    double media;

    // Leitura das notas
    cout << "Digite as notas dos " << NUM_ALUNOS << " alunos:" << endl;
    for (int i = 0; i < NUM_ALUNOS; ++i) {
        cout << "Nota do aluno " << i+1 << ": ";
        cin >> notas[i];
        soma += notas[i];
    }

    // Calculo da media
    media = soma / NUM_ALUNOS;

    // Impressao da media geral
    cout << "\nA media geral das notas dos alunos eh: " << media << endl;

    return 0;
}

