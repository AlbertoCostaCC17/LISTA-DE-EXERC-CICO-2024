#include <iostream>
#include <climits> // Para utilizar INT_MIN e INT_MAX
using namespace std;

int main() {
    const int TAMANHO = 5;
    int valores[TAMANHO];
    int maior = INT_MIN; // Inicializando com o menor valor possível para int
    int menor = INT_MAX; // Inicializando com o maior valor possível para int
    double soma = 0.0;
    double media;

    // Leitura dos valores
    cout << "Digite 5 valores inteiros:" << endl;
    for (int i = 0; i < TAMANHO; ++i) {
        cout << "Valor " << i+1 << ": ";
        cin >> valores[i];

        // Verificando e atualizando maior e menor
        if (valores[i] > maior) {
            maior = valores[i];
        }
        if (valores[i] < menor) {
            menor = valores[i];
        }

        // Somando para calcular a média
        soma += valores[i];
    }

    // Calculo da media
    media = soma / TAMANHO;

    // Impressao dos valores lidos, maior, menor e media
    cout << "\nValores lidos:" << endl;
    for (int i = 0; i < TAMANHO; ++i) {
        cout << valores[i] << " ";
    }
    cout << "\nMaior valor: " << maior << endl;
    cout << "Menor valor: " << menor << endl;
    cout << "Media dos valores: " << media << endl;

    return 0;
}
