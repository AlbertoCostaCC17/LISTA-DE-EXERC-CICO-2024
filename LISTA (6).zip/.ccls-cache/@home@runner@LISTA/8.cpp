#include <iostream>
using namespace std;

int main() {
    const int TAMANHO = 6;
    int valores[TAMANHO];

    // Leitura dos valores
    cout << "Digite 6 valores inteiros:" << endl;
    for (int i = 0; i < TAMANHO; ++i) {
        cout << "Valor " << i+1 << ": ";
        cin >> valores[i];
    }

    // Impressão dos valores na ordem inversa
    cout << "\nValores na ordem inversa:" << endl;
    for (int i = TAMANHO - 1; i >= 0; --i) {
        cout << valores[i] << endl;
    }

    return 0;
}
