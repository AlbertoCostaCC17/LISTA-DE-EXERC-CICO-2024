#include <iostream>
using namespace std;

int main() {
    const int TAMANHO = 50;
    int vetor[TAMANHO];

    // Preenchimento do vetor com a fórmula
    for (int i = 0; i < TAMANHO; ++i) {
        vetor[i] = (i + 5 * i) % (i + 1);
    }

    // Impressão do vetor
    cout << "Vetor preenchido com a formula (i + 5 * i) % (i + 1):" << endl;
    for (int i = 0; i < TAMANHO; ++i) {
        cout << vetor[i] << " ";
    }
    cout << endl;

    return 0;
}
