#include <iostream>
using namespace std;

int main() {
    const int TAMANHO = 10;
    double vetor[TAMANHO];
    double vetorQuadrado[TAMANHO];

    // Leitura dos valores
    cout << "Digite 10 numeros reais:" << endl;
    for (int i = 0; i < TAMANHO; ++i) {
        cout << "Numero " << i+1 << ": ";
        cin >> vetor[i];
    }

    // Calculo dos quadrados e armazenamento no vetorQuadrado
    for (int i = 0; i < TAMANHO; ++i) {
        vetorQuadrado[i] = vetor[i] * vetor[i];
    }

    // Impressão dos conjuntos
    cout << "\nConjunto de numeros originais:" << endl;
    for (int i = 0; i < TAMANHO; ++i) {
        cout << vetor[i] << " ";
    }
    cout << "\nConjunto de numeros ao quadrado:" << endl;
    for (int i = 0; i < TAMANHO; ++i) {
        cout << vetorQuadrado[i] << " ";
    }
    cout << endl;

    return 0;
}
