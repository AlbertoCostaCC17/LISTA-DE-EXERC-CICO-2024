#include <iostream>
using namespace std;

int main() {
    // Declarando o vetor A com 6 elementos
    int A[6];

    // (a) Atribuindo os valores ao vetor A
    A[0] = 1;
    A[1] = 0;
    A[2] = 5;
    A[3] = -2;
    A[4] = -5;
    A[5] = 7;

    // (b) Calculando e mostrando a soma de A[0], A[1] e A[5]
    int soma = A[0] + A[1] + A[5];
    cout << "Soma de A[0], A[1] e A[5]: " << soma << endl;

    return 0;
}
