#include <iostream>
using namespace std;

int main() {
    const int TAMANHO = 10;
    int vetor[TAMANHO];
    int contPares = 0;

    // Leitura dos valores
    cout << "Digite 10 numeros inteiros:" << endl;
    for (int i = 0; i < TAMANHO; ++i) {
        cout << "Numero " << i+1 << ": ";
        cin >> vetor[i];
    }

    // Contagem de valores pares
    for (int i = 0; i < TAMANHO; ++i) {
        if (vetor[i] % 2 == 0) {
            contPares++;
        }
    }

    // Impressão do resultado
    cout << "O vetor possui " << contPares << " valores pares." << endl;

    return 0;
}
