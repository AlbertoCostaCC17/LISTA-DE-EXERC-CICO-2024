#include <iostream>
#include <unordered_set>
using namespace std;

int main() {
    const int TAMANHO = 20;
    int vetor[TAMANHO];
    unordered_set<int> conjunto;

    // Leitura dos valores
    cout << "Digite 20 numeros inteiros para preencher o vetor:" << endl;
    for (int i = 0; i < TAMANHO; ++i) {
        cout << "Numero " << i+1 << ": ";
        cin >> vetor[i];
        conjunto.insert(vetor[i]); // Inserindo no conjunto para eliminar repetições
    }

    // Impressão dos elementos sem repetições
    cout << "\nElementos do vetor sem repeticoes:" << endl;
    for (int valor : conjunto) {
        cout << valor << " ";
    }
    cout << endl;

    return 0;
}
