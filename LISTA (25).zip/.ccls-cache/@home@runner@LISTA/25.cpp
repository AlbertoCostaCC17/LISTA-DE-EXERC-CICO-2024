#include <iostream>
using namespace std;

const int TAMANHO = 100;

bool nao_e_multiplo_de_sete(int num) {
    return num % 7 != 0;
}

bool termina_com_sete(int num) {
    return num % 10 == 7;
}

int main() {
    int vetor[TAMANHO];
    int numero = 1; // Começa com o primeiro número natural

    for (int i = 0; i < TAMANHO; ++i) {
        while (!(nao_e_multiplo_de_sete(numero) || termina_com_sete(numero))) {
            ++numero;
        }
        vetor[i] = numero;
        ++numero;
    }

    // Impressão do vetor
    cout << "Vetor com os 100 primeiros naturais que não são múltiplos de 7 ou terminam com 7:" << endl;
    for (int i = 0; i < TAMANHO; ++i) {
        cout << vetor[i] << " ";
        if ((i + 1) % 10 == 0) { // Quebra de linha a cada 10 elementos
            cout << endl;
        }
    }
    cout << endl;

    return 0;
}
