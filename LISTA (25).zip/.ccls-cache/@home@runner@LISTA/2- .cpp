#include <iostream>
using namespace std;

int main() {
    // Declarando o vetor para armazenar 6 valores inteiros
    int valores[6];

    // Solicitando que o usuário entre com os valores
    cout << "Digite 6 valores inteiros:" << endl;
    for (int i = 0; i < 6; ++i) {
        cout << "Valor " << i+1 << ": ";
        cin >> valores[i];
    }

    // Mostrando os valores lidos na tela
    cout << "\nValores digitados:" << endl;
    for (int i = 0; i < 6; ++i) {
        cout << valores[i] << endl;
    }

    return 0;
}
