#include <iostream>
#include <vector>
using namespace std;

bool eh_primo(int num) {
    if (num <= 1) {
        return false;
    }
    for (int i = 2; i * i <= num; ++i) {
        if (num % i == 0) {
            return false;
        }
    }
    return true;
}

int main() {
    const int TAMANHO = 10;
    vector<int> vetor(TAMANHO);

    // Leitura dos elementos do vetor
    cout << "Digite os " << TAMANHO << " numeros inteiros do vetor:" << endl;
    for (int i = 0; i < TAMANHO; ++i) {
        cout << "Elemento " << i + 1 << ": ";
        cin >> vetor[i];
    }

    // Verificação e impressão dos números primos e suas posições
    cout << "\nNumeros primos encontrados no vetor:" << endl;
    for (int i = 0; i < TAMANHO; ++i) {
        if (eh_primo(vetor[i])) {
            cout << "Posicao " << i << ": " << vetor[i] << endl;
        }
    }

    return 0;
}
