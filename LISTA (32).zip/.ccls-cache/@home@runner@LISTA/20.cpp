#include <iostream>
using namespace std;

int main() {
    const int TAMANHO = 10;
    int vetor[TAMANHO];
    int vetorImpares[TAMANHO];
    int indiceImpares = 0;

    // Leitura dos valores e preenchimento dos vetores
    cout << "Digite 10 numeros inteiros no intervalo [0, 50]:" << endl;
    for (int i = 0; i < TAMANHO; ++i) {
        cout << "Numero " << i+1 << ": ";
        cin >> vetor[i];

        if (vetor[i] % 2 != 0) {
            vetorImpares[indiceImpares] = vetor[i];
            indiceImpares++;
        }
    }

    // Impressao dos dois vetores, 2 elementos por linha
    cout << "\nVetor com todos os numeros:" << endl;
    for (int i = 0; i < TAMANHO; ++i) {
        cout << vetor[i] << " ";
        if ((i + 1) % 2 == 0) {
            cout << endl; // Quebra de linha a cada dois elementos
        }
    }
    cout << endl;

    cout << "\nVetor apenas com numeros impares:" << endl;
    for (int i = 0; i < indiceImpares; ++i) {
        cout << vetorImpares[i] << " ";
        if ((i + 1) % 2 == 0) {
            cout << endl; // Quebra de linha a cada dois elementos
        }
    }
    cout << endl;

    return 0;
}
