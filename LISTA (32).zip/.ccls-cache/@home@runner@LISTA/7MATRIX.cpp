#include <iostream>
using namespace std;

const int TAMANHO = 10;

int main() {
    int matriz[TAMANHO][TAMANHO];

    // Preenchimento da matriz conforme as condições dadas
    for (int i = 0; i < TAMANHO; ++i) {
        for (int j = 0; j < TAMANHO; ++j) {
            if (i < j) {
                matriz[i][j] = 2 * i + 7 * j * j;
            } else if (i == j) {
                matriz[i][j] = 3 * i * i - 1;
            } else {
                matriz[i][j] = 4 * i * i * i - 5 * j * j + 1;
            }
        }
    }

    // Impressão da matriz
    cout << "Matriz 10x10 gerada:" << endl;
    for (int i = 0; i < TAMANHO; ++i) {
        for (int j = 0; j < TAMANHO; ++j) {
            cout << matriz[i][j] << "\t";
        }
        cout << endl;
    }

    return 0;
}

