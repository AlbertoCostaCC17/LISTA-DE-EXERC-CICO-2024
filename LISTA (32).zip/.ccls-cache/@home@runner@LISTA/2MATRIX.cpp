#include <iostream>
using namespace std;

const int TAMANHO = 5;

int main() {
    int matriz[TAMANHO][TAMANHO];

    // Preenchimento da matriz
    for (int i = 0; i < TAMANHO; ++i) {
        for (int j = 0; j < TAMANHO; ++j) {
            if (i == j) {
                matriz[i][j] = 1;
            } else {
                matriz[i][j] = 0;
            }
        }
    }

    // Impressão da matriz
    cout << "Matriz 5x5 com 1 na diagonal principal e 0 nos demais elementos:" << endl;
    for (int i = 0; i < TAMANHO; ++i) {
        for (int j = 0; j < TAMANHO; ++j) {
            cout << matriz[i][j] << " ";
        }
        cout << endl;
    }

    return 0;
}
