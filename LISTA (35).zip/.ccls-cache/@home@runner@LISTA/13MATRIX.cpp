#include <iostream>
using namespace std;

const int TAMANHO = 4;

int main() {
    int matriz[TAMANHO][TAMANHO];

    // Gerando matriz 4x4 com valores aleatórios entre 1 e 20
    cout << "Matriz original:" << endl;
    for (int i = 0; i < TAMANHO; ++i) {
        for (int j = 0; j < TAMANHO; ++j) {
            matriz[i][j] = rand() % 20 + 1;
            cout << matriz[i][j] << " ";
        }
        cout << endl;
    }

    // Transformando em matriz triangular inferior
    cout << "\nMatriz transformada em matriz triangular inferior:" << endl;
    for (int i = 0; i < TAMANHO; ++i) {
        for (int j = i + 1; j < TAMANHO; ++j) {
            matriz[i][j] = 0;
        }
    }

    // Impressão da matriz transformada
    for (int i = 0; i < TAMANHO; ++i) {
        for (int j = 0; j < TAMANHO; ++j) {
            cout << matriz[i][j] << " ";
        }
        cout << endl;
    }

    return 0;
}
