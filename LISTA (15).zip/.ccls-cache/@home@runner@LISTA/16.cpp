#include <iostream>
using namespace std;

int main() {
    const int TAMANHO = 5;
    double vetor[TAMANHO];
    int codigo;

    // Leitura dos valores
    cout << "Digite 5 numeros reais para preencher o vetor:" << endl;
    for (int i = 0; i < TAMANHO; ++i) {
        cout << "Numero " << i+1 << ": ";
        cin >> vetor[i];
    }

    // Leitura do código
    cout << "\nDigite um codigo inteiro (0 para sair, 1 para ordem direta, 2 para ordem inversa): ";
    cin >> codigo;

    // Processamento de acordo com o código
    switch (codigo) {
        case 0:
            cout << "Programa finalizado." << endl;
            break;
        case 1:
            cout << "\nVetor na ordem direta:" << endl;
            for (int i = 0; i < TAMANHO; ++i) {
                cout << vetor[i] << " ";
            }
            cout << endl;
            break;
        case 2:
            cout << "\nVetor na ordem inversa:" << endl;
            for (int i = TAMANHO - 1; i >= 0; --i) {
                cout << vetor[i] << " ";
            }
            cout << endl;
            break;
        default:
            cout << "Codigo invalido." << endl;
            break;
    }

    return 0;
}
