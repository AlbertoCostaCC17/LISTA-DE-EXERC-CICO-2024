#include <iostream>
using namespace std;

int main() {
    const int TAMANHO = 10;
    int vetor[TAMANHO];

    // Leitura dos valores
    cout << "Digite 10 numeros inteiros para preencher o vetor:" << endl;
    for (int i = 0; i < TAMANHO; ++i) {
        cout << "Numero " << i+1 << ": ";
        cin >> vetor[i];

        // Verifica se o valor é negativo e atribui 0 se for
        if (vetor[i] < 0) {
            vetor[i] = 0;
        }
    }

    // Impressão do vetor com valores negativos alterados para 0
    cout << "\nVetor com valores negativos substituidos por 0:" << endl;
    for (int i = 0; i < TAMANHO; ++i) {
        cout << vetor[i] << " ";
    }
    cout << endl;

    return 0;
}
