#include <iostream>
using namespace std;

int main() {
    const int TAMANHO = 10;
    double vetor[TAMANHO];
    int contadorNegativos = 0;
    double somaPositivos = 0.0;

    // Leitura dos valores
    cout << "Digite 10 numeros reais:" << endl;
    for (int i = 0; i < TAMANHO; ++i) {
        cout << "Numero " << i+1 << ": ";
        cin >> vetor[i];

        if (vetor[i] < 0) {
            contadorNegativos++;
        } else {
            somaPositivos += vetor[i];
        }
    }

    // Impressão da quantidade de números negativos e da soma dos números positivos
    cout << "\nQuantidade de numeros negativos: " << contadorNegativos << endl;
    cout << "Soma dos numeros positivos: " << somaPositivos << endl;

    return 0;
}
