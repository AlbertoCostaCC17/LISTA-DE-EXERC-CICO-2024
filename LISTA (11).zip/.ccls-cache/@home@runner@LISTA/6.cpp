#include <iostream>
#include <climits> // Para utilizar INT_MIN e INT_MAX
using namespace std;

int main() {
    const int TAMANHO = 10;
    int vetor[TAMANHO];
    int maior, menor;

    // Leitura dos valores
    cout << "Digite 10 numeros inteiros:" << endl;
    for (int i = 0; i < TAMANHO; ++i) {
        cout << "Numero " << i+1 << ": ";
        cin >> vetor[i];
    }

    // Inicializando maior e menor com o primeiro elemento do vetor
    maior = vetor[0];
    menor = vetor[0];

    // Encontrando o maior e o menor elemento
    for (int i = 1; i < TAMANHO; ++i) {
        if (vetor[i] > maior) {
            maior = vetor[i];
        }
        if (vetor[i] < menor) {
            menor = vetor[i];
        }
    }

    // Impressão do maior e do menor elemento
    cout << "O maior elemento do vetor eh: " << maior << endl;
    cout << "O menor elemento do vetor eh: " << menor << endl;

    return 0;
}

