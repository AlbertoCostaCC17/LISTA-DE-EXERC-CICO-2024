#include <iostream>
using namespace std;

int main() {
    const int TAMANHO = 10;
    int vetor[TAMANHO];

    // Leitura dos valores
    cout << "Digite 10 numeros inteiros para preencher o vetor:" << endl;
    for (int i = 0; i < TAMANHO; ++i) {
        cout << "Numero " << i+1 << ": ";
        cin >> vetor[i];
    }

    // Verificação de valores iguais e impressão
    cout << "\nValores iguais no vetor:" << endl;
    bool encontrouIgual = false;
    for (int i = 0; i < TAMANHO; ++i) {
        for (int j = i + 1; j < TAMANHO; ++j) {
            if (vetor[i] == vetor[j]) {
                encontrouIgual = true;
                cout << vetor[i] << " ";
                break; // Para evitar imprimir o mesmo valor mais de uma vez
            }
        }
    }

    if (!encontrouIgual) {
        cout << "Nenhum valor igual encontrado no vetor." << endl;
    }

    return 0;
}
