#include <iostream>
using namespace std;

const int TAMANHO = 3;

int main() {
    int matriz[TAMANHO][TAMANHO];
    int soma_abaixo_diagonal = 0;

    // Leitura dos elementos da matriz
    cout << "Digite os elementos da matriz 3x3:" << endl;
    for (int i = 0; i < TAMANHO; ++i) {
        for (int j = 0; j < TAMANHO; ++j) {
            cout << "Elemento [" << i << "][" << j << "]: ";
            cin >> matriz[i][j];
        }
    }

    // Cálculo da soma dos elementos abaixo da diagonal principal
    for (int i = 1; i < TAMANHO; ++i) {  // Começa do índice 1 para estar abaixo da diagonal
        for (int j = 0; j < i; ++j) {
            soma_abaixo_diagonal += matriz[i][j];
        }
    }

    // Impressão da soma dos elementos abaixo da diagonal principal
    cout << "Soma dos elementos abaixo da diagonal principal: " << soma_abaixo_diagonal << endl;

    return 0;
}
