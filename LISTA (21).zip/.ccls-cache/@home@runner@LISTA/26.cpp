#include <iostream>
#include <cmath> // Para utilizar a função sqrt (raiz quadrada)
using namespace std;

const int TAMANHO = 10;

double calcular_media(int vetor[], int tamanho) {
    double soma = 0.0;
    for (int i = 0; i < tamanho; ++i) {
        soma += vetor[i];
    }
    return soma / tamanho;
}

double calcular_desvio_padrao(int vetor[], int tamanho) {
    double media = calcular_media(vetor, tamanho);
    double soma_quad_diff = 0.0;

    for (int i = 0; i < tamanho; ++i) {
        soma_quad_diff += pow(vetor[i] - media, 2);
    }

    return sqrt(soma_quad_diff / tamanho);
}

int main() {
    int vetor[TAMANHO];

    // Leitura dos elementos do vetor
    cout << "Digite os " << TAMANHO << " numeros inteiros do vetor:" << endl;
    for (int i = 0; i < TAMANHO; ++i) {
        cout << "Elemento " << i + 1 << ": ";
        cin >> vetor[i];
    }

    // Cálculo do desvio padrão
    double desvio_padrao = calcular_desvio_padrao(vetor, TAMANHO);

    // Impressão do resultado
    cout << "\nO desvio padrao do vetor e: " << desvio_padrao << endl;

    return 0;
}
