#include <iostream>
using namespace std;

int main() {
    const int TAMANHO = 10;
    int vetor[TAMANHO];
    int maior = INT_MAIN; // Inicializando com o menor valor possível para int
    int posicaoMaior = 0;

    // Leitura dos valores e identificação do maior elemento
    cout << "Digite 10 numeros inteiros:" << endl;
    for (int i = 0; i < TAMANHO; ++i) {
        cout << "Numero " << i+1 << ": ";
        cin >> vetor[i];

        // Verificando se o elemento atual é o maior encontrado até agora
        if (vetor[i] > maior) {
            maior = vetor[i];
            posicaoMaior = i;
        }
    }

    // Impressão do vetor
    cout << "\nVetor informado:" << endl;
    for (int i = 0; i < TAMANHO; ++i) {
        cout << vetor[i] << " ";
    }
    cout << endl;

    // Impressão do maior elemento e sua posição
    cout << "O maior elemento do vetor eh: " << maior << endl;
    cout << "Ele se encontra na posicao: " << posicaoMaior << endl;

    return 0;
}
