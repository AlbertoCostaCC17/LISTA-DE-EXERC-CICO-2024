#include <iostream>
using namespace std;

const int TAMANHO = 5;

int main() {
    int matriz[TAMANHO][TAMANHO];
    int valorX;
    bool encontrado = false;
    int linha_encontrado = -1, coluna_encontrado = -1;

    // Leitura da matriz
    cout << "Digite os elementos da matriz 5x5:" << endl;
    for (int i = 0; i < TAMANHO; ++i) {
        for (int j = 0; j < TAMANHO; ++j) {
            cout << "Elemento [" << i << "][" << j << "]: ";
            cin >> matriz[i][j];
        }
    }

    // Leitura do valor X a ser buscado
    cout << "Digite o valor X a ser buscado na matriz: ";
    cin >> valorX;

    // Busca pelo valor X na matriz
    for (int i = 0; i < TAMANHO; ++i) {
        for (int j = 0; j < TAMANHO; ++j) {
            if (matriz[i][j] == valorX) {
                encontrado = true;
                linha_encontrado = i;
                coluna_encontrado = j;
                break; // Encerra o loop ao encontrar o valor X
            }
        }
        if (encontrado) {
            break; // Encerra o loop externo ao encontrar o valor X
        }
    }

    // Verifica se o valor foi encontrado e imprime a localização ou mensagem de não encontrado
    if (encontrado) {
        cout << "Valor " << valorX << " encontrado na posicao [" << linha_encontrado << "][" << coluna_encontrado << "]" << endl;
    } else {
        cout << "Valor " << valorX << " nao encontrado na matriz." << endl;
    }

    return 0;
}
