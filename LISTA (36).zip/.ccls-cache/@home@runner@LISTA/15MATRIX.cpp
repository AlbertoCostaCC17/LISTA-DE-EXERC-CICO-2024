#include <iostream>
using namespace std;

const int ALUNOS = 5;
const int QUESTOES = 10;

int main() {
    char respostas_alunos[ALUNOS][QUESTOES];
    char gabarito[QUESTOES];
    int resultado[ALUNOS] = {0};

    // Leitura das respostas
