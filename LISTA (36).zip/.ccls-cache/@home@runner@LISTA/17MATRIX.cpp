#include <iostream>
using namespace std;

const int ALUNOS = 10;
const int PROVAS = 3;

int main() {
    int notas[ALUNOS][PROVAS];
    int piores_notas[PROVAS] = {0};

    // Leitura das notas dos alunos em cada prova
    cout << "Digite as notas dos " << ALUNOS << " alunos em " << PROVAS << " provas:" << endl;
    for (int i = 0; i < ALUNOS; ++i) {
        for (int j = 0; j < PROVAS; ++j) {
            cout << "Nota do aluno " << i + 1 << " na prova " << j + 1 << ": ";
            cin >> notas[i][j];
        }
    }

    // Cálculo das piores notas em cada prova
    for (int j = 0; j < PROVAS; ++j) {
        int menor_nota = notas[0][j];
        for (int i = 1; i < ALUNOS; ++i) {
            if (notas[i][j] < menor_nota) {
                menor_nota = notas[i][j];
            }
        }
        // Contabilizando o número de alunos com a pior nota na prova j
        for (int i = 0; i < ALUNOS; ++i) {
            if (notas[i][j] == menor_nota) {
                piores_notas[j]++;
                break; // Para contar cada aluno apenas uma vez
            }
        }
    }

    // Impressão do resultado
    cout << "\nNumero de alunos cuja pior nota foi na prova:" << endl;
    for (int j = 0; j < PROVAS; ++j) {
        cout << "Prova " << j + 1 << ": " << piores_notas[j] << " aluno(s)" << endl;
    }

    return 0;
}
